# Jenkinsfile examples

This directory contains example Jenkinsfiles, which are used with the Pipeline Multibranch functionality, or the Pipeline script from SCM functionality.
