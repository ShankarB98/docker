# Synopsis

This shows usage of a simple build wrapper, specifically the
AnsiColorBuildWrapper plugin, which adds ANSI coloring to the console output.

