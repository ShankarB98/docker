# Synopsis

This demonstrates how to push a tag (or branch, etc) to a remote Git
repository from within a Pipeline job. Currently it only contains an
example for pushing using username and password to authenticate.

# Note

This is not ideal - there is an open JIRA,
https://issues.jenkins-ci.org/browse/JENKINS-28335, for getting the
GitPublisher Jenkins functionality working with Pipeline.

# Credit

Based on Stackoverflow answer at http://stackoverflow.com/questions/33570075/tag-a-repo-from-a-jenkins-workflow-script
