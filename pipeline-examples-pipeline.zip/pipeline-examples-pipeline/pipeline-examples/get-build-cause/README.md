# Synopsis
Shows how to get the Cause(s) of a Pipeline build from within the
Pipeline script.

# Credit
Based on Stackoverflow answer at http://stackoverflow.com/questions/33587927/how-to-get-cause-in-workflow
